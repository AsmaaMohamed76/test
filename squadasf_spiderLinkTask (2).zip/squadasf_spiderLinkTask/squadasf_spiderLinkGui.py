import serial
from logging import setLogRecordFactory
from PyQt5.QtWidgets import QMainWindow , QApplication , QLabel , QPushButton , QLineEdit
from PyQt5 import uic
from PyQt5.QtCore import QDateTime , QTimer,pyqtSignal,pyqtSlot,QRunnable,QThreadPool
from PyQt5 import*

from PyQt5 import QtCore, QtGui, QtWidgets
import threading
from PyQt5.QtGui import QPixmap
from PyQt5.QtGui import QPixmap ,QImage
from threading import Thread , current_thread
from multiprocessing.connection import Client, Listener
from matplotlib.backend_bases import key_press_handler
import sys
from datetime import datetime
import subprocess
class UI(QMainWindow):
    def __init__(self):
        super(UI,self).__init__()
        uic.loadUi("ROV.ui" , self)
        self.arduinodata = serial.Serial('',9600)
        self.true = True
        while self.true :
            self.cmd = self.keyPressEvent()
            self.order = self.keyReleaseEvent()
            self.cmd = self.cmd + '\r'
            self.order = self.order + '\r'
            self.arduinodata.write(self.cmd.encode())
            self.arduinodata.write(self.order.encode())

        # counter
        self.count = 0
        # creating flag
        self.flag = False
        self.label = self.findChild(QLineEdit,"lineEdit")
        self.start = self.findChild(QPushButton,"start")
        self.stop = self.findChild(QPushButton,"stop")
        self.restart = self.findChild(QPushButton,"reset")
        self.autonmous = self.findChild(QPushButton,"autonmous")
        self.manual = self.findChild(QPushButton,"manual")
        self.stabilize = self.findChild(QPushButton,"stabilize")
        self.depth_hold = self.findChild(QPushButton,"depth_hold")
        self.label_2 = self.findChild(QLabel,"label_7")
        self.right =self.findChild(QLabel,"right")
        self.left =self.findChild(QLabel,"left")
        self.back =self.findChild(QLabel,"back")
        self.forward =self.findChild(QLabel,"forward")
        self.down =self.findChild(QLabel,"down")
        self.up =self.findChild(QLabel,"up")
        self.front =self.findChild(QLabel,"front")
        self.arm_2 =self.findChild(QLabel,"arm_2")
        self.arm_1 =self.findChild(QLabel,"arm_1")
        self.rotate_right =self.findChild(QLabel,"rotate_right")
        self.rotate_left =self.findChild(QLabel,"rotate_left")
        self.current_speed =self.findChild(QLineEdit,"current_speed")
        self.current_heading =self.findChild(QLineEdit,"current_heading")
        self.run = self.findChild(QPushButton,"run")
        self.run.clicked.connect(self.runScript)
        camThread1 = threading.Thread(target=self.cam_1)
        camThread1.start()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.clocker)
        self.start.clicked.connect(self.startTimer)
        self.stop.clicked.connect(self.endTimer)
        self.restart.clicked.connect(self.Re_set)
        self.autonmous.clicked.connect(self.press_it)
        self.manual.clicked.connect(self.press_it_2)
        self.stabilize.clicked.connect(self.press_it_3)
        self.depth_hold.clicked.connect(self.press_it_4)
        self.timer.start(1000)
        self.show()
    def press_it(self):
        self.label_2.setText("autonmous")
    def press_it_2(self):
        self.label_2.setText("manual")
    def press_it_3(self):
        self.label_2.setText("stabilize")
    def press_it_4(self):
        self.label_2.setText("depth_hold")
    def clocker(self):
        # checking if flag is true
        if self.flag:
            # incrementing the counter
            self.count+= 1
        # getting text from count
        text = str(self.count / 10)
        # showing text
        self.label.setText(text)
    def startTimer(self):
        self.flag = True
    def endTimer(self):
        self.flag = False
    def Re_set(self):
        # making flag to false
        self.flag = False
        # reseeting the count
        self.count = 0
        # setting text to label
        self.label.setText(str(self.count))
    def joystick(self):
        pass
    def keyPressEvent(self, event):
         inp=event.text()
         if(inp=='w'):
             self.front.setPixmap(QtGui.QPixmap("icons/frwrd-arrow.png"))
         if( inp=='s'):
             self.down.setPixmap(QtGui.QPixmap("icons/bckwrd-arrow.png"))
         if( inp=='d'):
             self.right.setPixmap(QtGui.QPixmap("icons/right-arrow.png"))
         if( inp=='a'):
            self.left.setPixmap(QtGui.QPixmap("icons/left-arrow.png"))
         if( inp=='r'):
             self.rotate_right.setPixmap(QtGui.QPixmap("icons/cw.png"))
         if( inp=='l'):
             self.rotate_left.setPixmap(QtGui.QPixmap("icons/ccw.png"))
         if( inp=='o'):
             self.arm_1.setPixmap(QtGui.QPixmap("icons/grapper-open.png"))
         if( inp=='c'):
             self.arm_2.setPixmap(QtGui.QPixmap("icons/grapper-open-horizontal.png"))
         if( inp=='f'):
             self.forward.setPixmap(QtGui.QPixmap("icons/upward-arrow.png"))
         if( inp=='b'):
             self.back.setPixmap(QtGui.QPixmap("icons/downward-arrow.png"))
    def keyReleaseEvent(self,event):
         inp=event.text()
         if(inp=='w'):
             self.front.setPixmap(QtGui.QPixmap("icons/frwrd-arrowred.png"))
         if( inp=='s'):
             self.down.setPixmap(QtGui.QPixmap("icons/bckwrd-arrowred.png"))
         if( inp=='d'):
             self.right.setPixmap(QtGui.QPixmap("icons/right-arrowred.png"))
         if( inp=='a'):
            self.left.setPixmap(QtGui.QPixmap("icons/left-arrowred.png"))
         if( inp=='r'):
             self.rotate_right.setPixmap(QtGui.QPixmap("icons/cwred.png"))
         if( inp=='l'):
             self.rotate_left.setPixmap(QtGui.QPixmap("icons/ccwred.png"))
         if( inp=='o'):
             self.arm_1.setPixmap(QtGui.QPixmap("icons/grapper-close.png"))
         if( inp=='c'):
             self.arm_2.setPixmap(QtGui.QPixmap("icons/grapper-close-horizontalpng.png"))
         if( inp=='f'):
             self.forward.setPixmap(QtGui.QPixmap("icons/upward-arrowred.png"))
         if( inp=='b'):
             self.back.setPixmap(QtGui.QPixmap("icons/downward-arrowred.png"))
    def convertToPix(self,msg):
        height, width, channel = msg.shape
        bytesPerLine = 3 * width
        qimg = QtGui.QImage(msg.data, width, height, bytesPerLine, QImage.Format_RGB888).rgbSwapped()
        pix = QtGui.QPixmap(qimg)
        return pix
    def camInit(self):
        address_1 = ('localhost',6000)
        listener = Listener(address_1, authkey=b'secret password')
        self.conn = listener.accept()
        print('connection accepted from', listener.last_accepted)
    @pyqtSlot()
    def cam_1(self):
        self.camInit()
        self.test = pyqtSignal()
        while True:
            try:
                msg1 = self.conn.recv()
                self.camera_1.setPixmap(self.convertToPix(msg1))
                self.test.emit("")
            except:
                continue
        listener.close()
    def runScript(self):
        if(self.code.currentIndex()==0):
            # exec(open("keyboard.py").read())
            args=["python","client.py"]
            process = subprocess.Popen(args, stdout=subprocess.PIPE)
        if(self.code.currentIndex()==1):
            # exec(open("keyboard.py").read())
            args=["python","keyboard.py"]
            process = subprocess.Popen(args, stdout=subprocess.PIPE)
app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()






















