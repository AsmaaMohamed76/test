from logging import setLogRecordFactory
from PyQt5.QtWidgets import QMainWindow , QApplication , QLabel , QPushButton , QLineEdit
from PyQt5 import uic
from PyQt5.QtCore import QDateTime , QTimer,pyqtSignal,pyqtSlot,QRunnable,QThreadPool
from PyQt5 import*

from PyQt5 import QtCore, QtGui, QtWidgets
import threading
from PyQt5.QtGui import QPixmap
from PyQt5.QtGui import QPixmap ,QImage
from threading import Thread , current_thread
from multiprocessing.connection import Client, Listener
from matplotlib.backend_bases import key_press_handler
import sys
from datetime import datetime
import subprocess


class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
    def setupUi(self):
        self.setObjectName("MainWindow")
        self.resize(961, 685)
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")
        self.camera_1 = QtWidgets.QLabel(self.centralwidget)
        self.camera_1.setGeometry(QtCore.QRect(10, 10, 461, 341))
        self.camera_1.setFrameShape(QtWidgets.QFrame.Box)
        self.camera_1.setFrameShadow(QtWidgets.QFrame.Raised)
        self.camera_1.setAlignment(QtCore.Qt.AlignCenter)
        self.camera_1.setObjectName("camera_1")
        self.camera_2 = QtWidgets.QLabel(self.centralwidget)
        self.camera_2.setGeometry(QtCore.QRect(474, 10, 461, 341))
        self.camera_2.setFrameShape(QtWidgets.QFrame.Box)
        self.camera_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.camera_2.setAlignment(QtCore.Qt.AlignCenter)
        self.camera_2.setObjectName("camera_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(10, 360, 441, 251))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.label_3.setFont(font)
        self.label_3.setAutoFillBackground(False)
        self.label_3.setFrameShape(QtWidgets.QFrame.Box)
        self.label_3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.label_3.setLineWidth(2)
        self.label_3.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_3.setIndent(-1)
        self.label_3.setObjectName("label_3")
        self.timer = QtWidgets.QLabel(self.centralwidget)
        self.timer.setGeometry(QtCore.QRect(460, 360, 281, 81))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.timer.setFont(font)
        self.timer.setFrameShape(QtWidgets.QFrame.Box)
        self.timer.setFrameShadow(QtWidgets.QFrame.Raised)
        self.timer.setLineWidth(2)
        self.timer.setTextFormat(QtCore.Qt.AutoText)
        self.timer.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.timer.setObjectName("timer")
        self.start = QtWidgets.QPushButton(self.centralwidget)
        self.start.setGeometry(QtCore.QRect(470, 410, 71, 21))
        self.start.setObjectName("start")
        self.stop = QtWidgets.QPushButton(self.centralwidget)
        self.stop.setGeometry(QtCore.QRect(570, 410, 71, 21))
        self.stop.setObjectName("stop")
        self.reset = QtWidgets.QPushButton(self.centralwidget)
        self.reset.setGeometry(QtCore.QRect(660, 410, 71, 21))
        self.reset.setObjectName("reset")
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(550, 370, 113, 22))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit.setFont(font)
        self.lineEdit.setFrame(False)
        self.lineEdit.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit.setObjectName("lineEdit")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(460, 450, 281, 161))
        self.label_5.setFrameShape(QtWidgets.QFrame.Box)
        self.label_5.setFrameShadow(QtWidgets.QFrame.Raised)
        self.label_5.setLineWidth(2)
        self.label_5.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_5.setObjectName("label_5")
        self.lineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(470, 490, 141, 22))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_3.setGeometry(QtCore.QRect(470, 520, 141, 22))
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.lineEdit_4 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_4.setGeometry(QtCore.QRect(470, 550, 141, 22))
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.lineEdit_5 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_5.setGeometry(QtCore.QRect(470, 580, 141, 22))
        self.lineEdit_5.setObjectName("lineEdit_5")
        self.scripts = QtWidgets.QLabel(self.centralwidget)
        self.scripts.setGeometry(QtCore.QRect(750, 360, 181, 81))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.scripts.setFont(font)
        self.scripts.setFrameShape(QtWidgets.QFrame.Box)
        self.scripts.setFrameShadow(QtWidgets.QFrame.Raised)
        self.scripts.setLineWidth(2)
        self.scripts.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.scripts.setObjectName("scripts")
        self.code = QtWidgets.QComboBox(self.centralwidget)
        self.code.setGeometry(QtCore.QRect(760, 400, 73, 22))
        self.code.setEditable(True)
        self.code.setObjectName("code")
        self.run = QtWidgets.QPushButton(self.centralwidget)
        self.run.setGeometry(QtCore.QRect(840, 400, 71, 21))
        self.run.setObjectName("run")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(750, 450, 181, 161))
        self.label_7.setFrameShape(QtWidgets.QFrame.Box)
        self.label_7.setFrameShadow(QtWidgets.QFrame.Raised)
        self.label_7.setLineWidth(2)
        self.label_7.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_7.setObjectName("label_7")
        self.autonmous = QtWidgets.QPushButton(self.centralwidget)
        self.autonmous.setGeometry(QtCore.QRect(760, 480, 93, 28))
        self.autonmous.setObjectName("autonmous")
        self.manual = QtWidgets.QPushButton(self.centralwidget)
        self.manual.setGeometry(QtCore.QRect(760, 570, 93, 28))
        self.manual.setObjectName("manual")
        self.stabilize = QtWidgets.QPushButton(self.centralwidget)
        self.stabilize.setGeometry(QtCore.QRect(760, 540, 93, 28))
        self.stabilize.setObjectName("stabilize")
        self.depth_hold = QtWidgets.QPushButton(self.centralwidget)
        self.depth_hold.setGeometry(QtCore.QRect(760, 510, 93, 28))
        self.depth_hold.setObjectName("depth_hold")
        self.label_12 = QtWidgets.QLabel(self.centralwidget)
        self.label_12.setGeometry(QtCore.QRect(300, 390, 141, 101))
        self.label_12.setFrameShape(QtWidgets.QFrame.Box)
        self.label_12.setFrameShadow(QtWidgets.QFrame.Plain)
        self.label_12.setLineWidth(1)
        self.label_12.setText("")
        self.label_12.setObjectName("label_12")
        self.arm_2 = QtWidgets.QLabel(self.centralwidget)
        self.arm_2.setGeometry(QtCore.QRect(160, 390, 141, 101))
        self.arm_2.setFrameShape(QtWidgets.QFrame.Box)
        self.arm_2.setFrameShadow(QtWidgets.QFrame.Plain)
        self.arm_2.setText("")
        self.arm_2.setPixmap(QtGui.QPixmap("icons/grapper-close-horizontalpng.png"))
        self.arm_2.setScaledContents(True)
        self.arm_2.setObjectName("arm_2")
        self.rotate = QtWidgets.QLabel(self.centralwidget)
        self.rotate.setGeometry(QtCore.QRect(160, 490, 141, 101))
        self.rotate.setFrameShape(QtWidgets.QFrame.Box)
        self.rotate.setFrameShadow(QtWidgets.QFrame.Plain)
        self.rotate.setText("")
        self.rotate.setObjectName("rotate")
        self.arm_1 = QtWidgets.QLabel(self.centralwidget)
        self.arm_1.setGeometry(QtCore.QRect(20, 390, 141, 101))
        self.arm_1.setFrameShape(QtWidgets.QFrame.Box)
        self.arm_1.setFrameShadow(QtWidgets.QFrame.Plain)
        self.arm_1.setText("")
        self.arm_1.setPixmap(QtGui.QPixmap("icons/grapper-close.png"))
        self.arm_1.setScaledContents(True)
        self.arm_1.setAlignment(QtCore.Qt.AlignCenter)
        self.arm_1.setObjectName("arm_1")
        self.front = QtWidgets.QLabel(self.centralwidget)
        self.front.setGeometry(QtCore.QRect(60, 490, 51, 31))
        self.front.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.front.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.front.setText("")
        self.front.setPixmap(QtGui.QPixmap("icons/frwrd-arrowred.png"))
        self.front.setScaledContents(True)
        self.front.setAlignment(QtCore.Qt.AlignCenter)
        self.front.setObjectName("front")
        self.right = QtWidgets.QLabel(self.centralwidget)
        self.right.setGeometry(QtCore.QRect(110, 520, 41, 41))
        self.right.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.right.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.right.setText("")
        self.right.setPixmap(QtGui.QPixmap("icons/right-arrowred.png"))
        self.right.setScaledContents(True)
        self.right.setAlignment(QtCore.Qt.AlignCenter)
        self.right.setObjectName("right")
        self.left = QtWidgets.QLabel(self.centralwidget)
        self.left.setGeometry(QtCore.QRect(20, 520, 41, 41))
        self.left.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.left.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.left.setText("")
        self.left.setPixmap(QtGui.QPixmap("icons/left-arrowred.png"))
        self.left.setScaledContents(True)
        self.left.setAlignment(QtCore.Qt.AlignCenter)
        self.left.setObjectName("left")
        self.down = QtWidgets.QLabel(self.centralwidget)
        self.down.setGeometry(QtCore.QRect(60, 560, 51, 31))
        self.down.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.down.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.down.setText("")
        self.down.setPixmap(QtGui.QPixmap("icons/bckwrd-arrowred.png"))
        self.down.setScaledContents(True)
        self.down.setAlignment(QtCore.Qt.AlignCenter)
        self.down.setObjectName("down")
        self.arrows = QtWidgets.QLabel(self.centralwidget)
        self.arrows.setGeometry(QtCore.QRect(20, 490, 141, 101))
        self.arrows.setFrameShape(QtWidgets.QFrame.Box)
        self.arrows.setFrameShadow(QtWidgets.QFrame.Plain)
        self.arrows.setText("")
        self.arrows.setObjectName("arrows")
        self.rotate_right = QtWidgets.QLabel(self.centralwidget)
        self.rotate_right.setGeometry(QtCore.QRect(170, 490, 121, 41))
        self.rotate_right.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.rotate_right.setText("")
        self.rotate_right.setPixmap(QtGui.QPixmap("icons/cwred.png"))
        self.rotate_right.setScaledContents(True)
        self.rotate_right.setObjectName("rotate_right")
        self.rotate_left = QtWidgets.QLabel(self.centralwidget)
        self.rotate_left.setGeometry(QtCore.QRect(170, 550, 121, 41))
        self.rotate_left.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.rotate_left.setText("")
        self.rotate_left.setPixmap(QtGui.QPixmap("icons/ccwred.png"))
        self.rotate_left.setScaledContents(True)
        self.rotate_left.setObjectName("rotate_left")
        self.label_17 = QtWidgets.QLabel(self.centralwidget)
        self.label_17.setGeometry(QtCore.QRect(300, 490, 141, 101))
        self.label_17.setFrameShape(QtWidgets.QFrame.Box)
        self.label_17.setFrameShadow(QtWidgets.QFrame.Plain)
        self.label_17.setText("")
        self.label_17.setObjectName("label_17")
        self.forward = QtWidgets.QLabel(self.centralwidget)
        self.forward.setGeometry(QtCore.QRect(330, 490, 81, 41))
        self.forward.setText("")
        self.forward.setPixmap(QtGui.QPixmap("icons/upward-arrowred.png"))
        self.forward.setScaledContents(True)
        self.forward.setObjectName("forward")
        self.back = QtWidgets.QLabel(self.centralwidget)
        self.back.setGeometry(QtCore.QRect(330, 550, 81, 41))
        self.back.setText("")
        self.back.setPixmap(QtGui.QPixmap("icons/downward-arrowred.png"))
        self.back.setScaledContents(True)
        self.back.setObjectName("back")
        self.background = QtWidgets.QLabel(self.centralwidget)
        self.background.setGeometry(QtCore.QRect(0, 0, 961, 631))
        self.background.setText("")
        self.background.setPixmap(QtGui.QPixmap("icons/a.jpg"))
        self.background.setScaledContents(True)
        self.background.setObjectName("background")
        self.current_speed = QtWidgets.QLineEdit(self.centralwidget)
        self.current_speed.setGeometry(QtCore.QRect(310, 400, 121, 22))
        self.current_speed.setObjectName("current_speed")
        self.current_heading = QtWidgets.QLineEdit(self.centralwidget)
        self.current_heading.setGeometry(QtCore.QRect(310, 430, 121, 22))
        self.current_heading.setObjectName("current_heading")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 490, 141, 101))
        self.label.setFrameShape(QtWidgets.QFrame.Box)
        self.label.setText("")
        self.label.setObjectName("label")
        self.arrows.raise_()
        self.background.raise_()
        self.label_3.raise_()
        self.camera_1.raise_()
        self.camera_2.raise_()
        self.timer.raise_()
        self.start.raise_()
        self.stop.raise_()
        self.reset.raise_()
        self.lineEdit.raise_()
        self.label_5.raise_()
        self.lineEdit_2.raise_()
        self.lineEdit_3.raise_()
        self.lineEdit_4.raise_()
        self.lineEdit_5.raise_()
        self.scripts.raise_()
        self.code.raise_()
        self.run.raise_()
        self.label_7.raise_()
        self.autonmous.raise_()
        self.manual.raise_()
        self.stabilize.raise_()
        self.depth_hold.raise_()
        self.label_12.raise_()
        self.arm_2.raise_()
        self.rotate.raise_()
        self.arm_1.raise_()
        self.front.raise_()
        self.right.raise_()
        self.left.raise_()
        self.down.raise_()
        self.rotate_right.raise_()
        self.rotate_left.raise_()
        self.label_17.raise_()
        self.forward.raise_()
        self.back.raise_()
        self.current_speed.raise_()
        self.current_heading.raise_()
        self.label.raise_()
        self.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(self)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 961, 26))
        self.menubar.setObjectName("menubar")
        self.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(self)
        self.statusbar.setObjectName("statusbar")
        self.setStatusBar(self.statusbar)
        self.key_press()
        keyPressed = QtCore.pyqtSignal(int)
        self.retranslateUi(self)
        QtCore.QMetaObject.connectSlotsByName(self)
        camThread1 = threading.Thread(target=self.cam_1)
        camThread1.start()
        self.threadpool = QThreadPool()
        self.threadpool.start(self.cameraworker)
        
        self.retranslateUi(self)
        self.x
        QtCore.QMetaObject.connectSlotsByName(self)
    def joystick(self):
        pass  
    # def keyPressEvent(self, event):
    #     super(Ui_MainWindow, self).keyPressEvent(event)
    #     self.keyPressed.emit(event.key())
    #     if type(event) == QtGui.QKeyEvent:
    #         if event.key() == 'w':
    #             self.up.setPixmap(QtGui.QPixmap("icons/frwrd-arrow.png"))
    #         if event.key() == 's':     
    #             self.down.setPixmap(QtGui.QPixmap("icons/bckwrd-arrow.png"))
    #         if event.key() == 'd':
    #             self.right.setPixmap(QtGui.QPixmap("icons/right-arrow.png"))
    #         if event.key() == 'a':  
    #             self.right.setPixmap(QtGui.QPixmap("icons/right-arrow.png"))   
    # def keyreleaseEvent(self, event):
    #   if type(event) == QtGui.QKeyEvent:
    #      if event.key() == 'w':
    #           self.up.setPixmap(QtGui.QPixmap("icons/frwrd-arrowred.png"))
    #      if event.key() == 's':     
    #          self.down.setPixmap(QtGui.QPixmap("icons/bckwrd-arrowred.png"))
    #      if event.key() == 'd':
    #           self.right.setPixmap(QtGui.QPixmap("icons/right-arrowred.png"))
    #      if event.key() == 'a':  
    #          self.right.setPixmap(QtGui.QPixmap("icons/right-arrowred.png"))          
             
    def key_press(self,x):
         inp=x.text()
         if(inp=='w'):
             self.up.setPixmap(QtGui.QPixmap("icons/frwrd-arrow.png"))
         if( inp=='s'):
             self.down.setPixmap(QtGui.QPixmap("icons/bckwrd-arrow.png")) 
         if( inp=='d'):
             self.right.setPixmap(QtGui.QPixmap("icons/right-arrow.png"))    
         if( inp=='a'):
             self.left.setPixmap(QtGui.QPixmap("icons/left-arrow.png"))
    def key_rel(self,x):
         inp=x.text()
         if(inp=='w'):
             self.up.setPixmap(QtGui.QPixmap("icons/frwrd-arrowred.png"))
         if( inp=='s'):
             self.down.setPixmap(QtGui.QPixmap("icons/bckwrd-arrowred.png")) 
         if( inp=='d'):
             self.right.setPixmap(QtGui.QPixmap("icons/right-arrowred.png"))    
         if( inp=='a'):
            self.left.setPixmap(QtGui.QPixmap("icons/left-arrowred.png"))           
         
                 
    def convertToPix(self,msg):
        height, width, channel = msg.shape
        bytesPerLine = 3 * width
        qimg = QtGui.QImage(msg.data, width, height, bytesPerLine, QImage.Format_RGB888).rgbSwapped()
        pix = QtGui.QPixmap(qimg)
        return pix

    def camInit(self):
        address_1 = ('localhost',6000)
        listener = Listener(address_1, authkey=b'secret password')
        self.conn = listener.accept()
        print('connection accepted from', listener.last_accepted)
    @pyqtSlot()
    def cam_1(self):
        self.camInit()
        self.test = pyqtSignal()
        
        while True:
            try:
                msg1 = self.conn.recv()
                self.camera_1.setPixmap(self.convertToPix(msg1))
                self.test.emit("")
            except:
                continue
        listener.close()   
    def runScript(self):
        if(self.code.currentIndex()==0):
            # exec(open("keyboard.py").read())
            args=["python","client.py"]
            process = subprocess.Popen(args, stdout=subprocess.PIPE)
        if(self.code.currentIndex()==1):
            # exec(open("keyboard.py").read())
            args=["python","keyboard.py"]
            process = subprocess.Popen(args, stdout=subprocess.PIPE)  
    # self.count = 0
    # self.flag = False
    # self.timer = QTimer(self)
    # self.timer.timeout.connect(self.clocker)
    # self.timer.start(1000)
    def press_it(self):
        self.label_7.setText("autonmous")
    def press_it_2(self):
        self.label_7.setText("manual")
    def press_it_3(self):
        self.label_7.setText("stabilize")
    def press_it_4(self):
        self.label_7.setText("depth_hold")
        
    def clocker(self):
        # checking if flag is true
        if self.flag:
            # incrementing the counter
            self.count+= 1
        # getting text from count
        text = str(self.count / 10)
        # showing text
        self.lineEdit.setText(text)
    def startTimer(self):
        self.flag = True
    def endTimer(self):
        self.flag = False
    def Re_set(self):
        # making flag to false
        self.flag = False
        # reseeting the count
        self.count = 0
        # setting text to label
        self.lineEdit.setText(str(self.count))  
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.camera_1.setText(_translate("MainWindow", "Camera 1"))
        self.camera_2.setText(_translate("MainWindow", "Camera 2"))
        self.label_3.setText(_translate("MainWindow", "Vehicle Indicators"))
        self.timer.setText(_translate("MainWindow", "Timer"))
        self.start.setText(_translate("MainWindow", "Start"))
        self.stop.setText(_translate("MainWindow", "Stop"))
        self.reset.setText(_translate("MainWindow", "Reset"))
        self.lineEdit.setText(_translate("MainWindow", "00:00:00"))
        self.label_5.setText(_translate("MainWindow", "Sensor Readings"))
        self.lineEdit_2.setText(_translate("MainWindow", "Depth: "))
        self.lineEdit_3.setText(_translate("MainWindow", "X acc: "))
        self.lineEdit_4.setText(_translate("MainWindow", "Y acc: "))
        self.lineEdit_5.setText(_translate("MainWindow", "Z acc: "))
        self.scripts.setText(_translate("MainWindow", "Scripts"))
        self.code.setCurrentText(_translate("MainWindow", "Code1"))
        self.run.setText(_translate("MainWindow", "Run"))
        self.label_7.setText(_translate("MainWindow", "Current Mode"))
        self.autonmous.setText(_translate("MainWindow", "Autonmous"))
        self.manual.setText(_translate("MainWindow", "Manual"))
        self.stabilize.setText(_translate("MainWindow", "Stabilize"))
        self.depth_hold.setText(_translate("MainWindow", "Depth Hold"))
        self.current_speed.setText(_translate("MainWindow", "CurrentSpeed:"))
        self.current_heading.setText(_translate("MainWindow", "CurrentHeading:"))
class Camera1Worker(QRunnable):
    def _init_(self,ui):
        super(Camera1Worker,self)._init_()
        ui = self.ui

    @pyqtSlot()
    def run(self):
        self.test = pyqtSignal()
        self.ui.camInit()
        while True:
            try:   
                msg1=self.ui.conn.recv()
                self.ui.camera_1.setPixmap(self.ui.convertToPix(msg1))
                self.test.emit('')
            except:
                continue
    
import icons


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi()
    ui.show()
    sys.exit(app.exec_())
