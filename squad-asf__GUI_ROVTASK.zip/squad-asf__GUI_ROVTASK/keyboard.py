from PyQt5.QtWidgets import QMainWindow , QApplication , QLabel , QPushButton , QLineEdit , QFileDialog
from PyQt5 import uic
from PyQt5.QtCore import QDateTime , QTimer
import sys
from datetime import datetime
from PyQt5.QtGui import QPixmap , QKeyEvent

class UI(QMainWindow):
    def __init__(self):
        super(UI,self).__init__()

        uic.loadUi("ROV (2).ui" , self)
        # counter
        self.count = 0
  
        # creating flag
        self.flag = False
        self.label = self.findChild(QLineEdit,"lineEdit")
        self.start = self.findChild(QPushButton,"start")
        self.stop = self.findChild(QPushButton,"stop")
        self.restart = self.findChild(QPushButton,"reset")
        self.autonmous = self.findChild(QPushButton,"autonmous")
        self.manual = self.findChild(QPushButton,"manual")
        self.stabilize = self.findChild(QPushButton,"stabilize")
        self.depth_hold = self.findChild(QPushButton,"depth_hold")
        self.label_2 = self.findChild(QLabel,"label_7")
        self.label_3 = self.findChild(QLineEdit,"current_heading")
        self.front = self.findChild(QLabel,"front")
        self.right = self.findChild(QLabel,"right")
        self.left = self.findChild(QLabel,"left")
        self.down = self.findChild(QLabel,"down")

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.clocker)
        self.label_3.returnPressed.connect(lambda: self.key_press())
        self.start.clicked.connect(self.startTimer)
        self.stop.clicked.connect(self.endTimer)
        self.restart.clicked.connect(self.Re_set)
        self.autonmous.clicked.connect(self.press_it)
        self.manual.clicked.connect(self.press_it_2)
        self.stabilize.clicked.connect(self.press_it_3)
        self.depth_hold.clicked.connect(self.press_it_4)
        
        self.timer.start(1000)
        self.show()
       

        



      

    def press_it(self):
        self.label_2.setText("autonmous")

    def press_it_2(self):
        self.label_2.setText("manual")

    def press_it_3(self):
        self.label_2.setText("stabilize")

    def press_it_4(self):
        self.label_2.setText("depth_hold")

    def clocker(self):
        # checking if flag is true
        if self.flag:
  
            # incrementing the counter
            self.count+= 1
  
        # getting text from count
        text = str(self.count / 10)
  
        # showing text
        self.label.setText(text)
  
  
    def startTimer(self):
        self.flag = True

    def endTimer(self):
        self.flag = False

    def Re_set(self):
  
        # making flag to false
        self.flag = False
  
        # reseeting the count
        self.count = 0
  
        # setting text to label
        self.label.setText(str(self.count))
    
  

    def key_press(self):
        inp= self.label_3.text()
        if(inp=='f'):
            self.front.setPixmap(QPixmap("icons/frwrd-arrow.png"))
            self.right.setPixmap(QPixmap("icons/right-arrowred.png"))
            self.left.setPixmap(QPixmap("icons/left-arrowred.png"))
            self.down.setPixmap(QPixmap("icons/bckwrd-arrowred.png"))
        if( inp=='d'):
            self.front.setPixmap(QPixmap("icons/frwrd-arrowred.png"))
            self.right.setPixmap(QPixmap("icons/right-arrowred.png"))
            self.left.setPixmap(QPixmap("icons/left-arrowred.png"))
            self.down.setPixmap(QPixmap("icons/bckwrd-arrow.png"))
        if( inp=='r'):
            self.front.setPixmap(QPixmap("icons/frwrd-arrowred.png"))
            self.left.setPixmap(QPixmap("icons/left-arrowred.png"))
            self.down.setPixmap(QPixmap("icons/bckwrd-arrowred.png"))
            self.right.setPixmap(QPixmap("icons/right-arrow.png"))
        if( inp=='l'):
            self.front.setPixmap(QPixmap("icons/frwrd-arrowred.png"))
            self.right.setPixmap(QPixmap("icons/right-arrowred.png"))
            self.down.setPixmap(QPixmap("icons/bckwrd-arrowred.png"))
            self.left.setPixmap(QPixmap("icons/left-arrow.png"))
  

app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()