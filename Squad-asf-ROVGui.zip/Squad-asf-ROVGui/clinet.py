from multiprocessing.connection import Client
import cv2 as cv

address_1 = ('localhost',6000)
client = Client(address_1, authkey=b'secret password')
vid = cv.VideoCapture(0)
while True:
    ret, frame = vid.read()
        
    cv.imshow('frame', frame)
    key = cv.waitKey(1)
            
    if ret:
        client.send(frame)
        
client.close()
vid.close()